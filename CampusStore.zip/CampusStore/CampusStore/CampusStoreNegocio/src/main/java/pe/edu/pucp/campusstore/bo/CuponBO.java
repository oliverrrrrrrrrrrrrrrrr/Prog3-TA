package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Cupon;

public interface CuponBO extends Gestionable<Cupon>{
    
}
