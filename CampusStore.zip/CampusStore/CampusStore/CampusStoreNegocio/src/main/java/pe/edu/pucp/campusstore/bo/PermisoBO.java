package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Permiso;

public interface PermisoBO extends Gestionable<Permiso>{
    
}
