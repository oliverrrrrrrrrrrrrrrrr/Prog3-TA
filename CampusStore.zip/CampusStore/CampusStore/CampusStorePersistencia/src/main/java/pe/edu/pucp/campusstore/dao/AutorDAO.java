package pe.edu.pucp.campusstore.dao;

import pe.edu.pucp.campusstore.interfaces.dao.Persistible;
import pe.edu.pucp.campusstore.modelo.Autor;

public interface AutorDAO extends Persistible<Autor, Integer> {    
}
