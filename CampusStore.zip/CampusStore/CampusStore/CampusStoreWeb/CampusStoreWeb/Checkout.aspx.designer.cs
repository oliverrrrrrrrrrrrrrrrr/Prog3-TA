//------------------------------------------------------------------------------
// <generado autom�ticamente>
//     Este c�digo fue generado por una herramienta.
//
//     Los cambios en este archivo podr�an causar un comportamiento incorrecto y se perder�n si
//     se vuelve a generar el c�digo. 
// </generado autom�ticamente>
//------------------------------------------------------------------------------

namespace CampusStoreWeb
{


    public partial class Checkout
    {

        /// <summary>
        /// Control pnlMensaje.
        /// </summary>
        /// <remarks>
        /// Campo generado automticamente.
        /// Para modificarlo, mueva la declaracin del campo del archivo del diseador al archivo de cdigo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Panel pnlMensaje;

        /// <summary>
        /// Control iconMensaje.
        /// </summary>
        /// <remarks>
        /// Campo generado automticamente.
        /// Para modificarlo, mueva la declaracin del campo del archivo del diseador al archivo de cdigo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label iconMensaje;

        /// <summary>
        /// Control lblMensaje.
        /// </summary>
        /// <remarks>
        /// Campo generado automticamente.
        /// Para modificarlo, mueva la declaracin del campo del archivo del diseador al archivo de cdigo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblMensaje;

        /// <summary>
        /// Control lblOrderId.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblOrderId;

        /// <summary>
        /// Control lblProductCount.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblProductCount;

        /// <summary>
        /// Control lblOrderDate.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblOrderDate;

        /// <summary>
        /// Control lblOrderTotal.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblOrderTotal;

        /// <summary>
        /// Control lblProductCountHeader.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label lblProductCountHeader;

        /// <summary>
        /// Control rptDetalleOrden.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Repeater rptDetalleOrden;

        /// <summary>
        /// Control btnProceedPayment.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.LinkButton btnProceedPayment;
    }
}
