//------------------------------------------------------------------------------
// <generado autom�ticamente>
//     Este c�digo fue generado por una herramienta.
//
//     Los cambios en este archivo podr�an causar un comportamiento incorrecto y se perder�n si
//     se vuelve a generar el c�digo. 
// </generado autom�ticamente>
//------------------------------------------------------------------------------

namespace CampusStoreWeb
{


    public partial class Settings
    {

        /// <summary>
        /// Control txtUsername.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtUsername;

        /// <summary>
        /// Control txtFullName.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtFullName;

        /// <summary>
        /// Control txtEmail.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtEmail;

        /// <summary>
        /// Control cvSignUpError.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.CustomValidator cvSignUpError;

        /// <summary>
        /// Control btnSaveAccountChanges.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btnSaveAccountChanges;

        /// <summary>
        /// Control txtCurrentPassword.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtCurrentPassword;

        /// <summary>
        /// Control txtNewPassword.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtNewPassword;

        /// <summary>
        /// Control txtConfirmPassword.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox txtConfirmPassword;

        /// <summary>
        /// Control btnChangePassword.
        /// </summary>
        /// <remarks>
        /// Campo generado autom�ticamente.
        /// Para modificarlo, mueva la declaraci�n del campo del archivo del dise�ador al archivo de c�digo subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button btnChangePassword;
    }
}
