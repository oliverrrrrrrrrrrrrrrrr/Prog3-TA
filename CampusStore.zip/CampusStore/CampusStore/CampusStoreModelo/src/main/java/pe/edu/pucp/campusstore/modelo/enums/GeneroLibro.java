package pe.edu.pucp.campusstore.modelo.enums;

public enum GeneroLibro {
    DRAMA, FANTASIA, NOVELA, NARRATIVO, AVENTURA, CIENCIA_FICCION
}
