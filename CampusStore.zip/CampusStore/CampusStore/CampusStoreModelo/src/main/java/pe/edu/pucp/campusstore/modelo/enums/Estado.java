package pe.edu.pucp.campusstore.modelo.enums;

public enum Estado {
    Nuevo, 
    Modificado, 
    Eliminado
}
