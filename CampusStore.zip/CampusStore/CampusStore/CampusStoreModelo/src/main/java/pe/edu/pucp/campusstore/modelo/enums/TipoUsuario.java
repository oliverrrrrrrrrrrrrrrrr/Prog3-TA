package pe.edu.pucp.campusstore.modelo.enums;

public enum TipoUsuario {
    CLIENTE, EMPLEADO
}
