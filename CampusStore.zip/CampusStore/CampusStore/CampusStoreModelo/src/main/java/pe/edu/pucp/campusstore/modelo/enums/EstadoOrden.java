package pe.edu.pucp.campusstore.modelo.enums;

public enum EstadoOrden {
    NO_PAGADO, PAGADO, ENTREGADO, CANCELADO
}
