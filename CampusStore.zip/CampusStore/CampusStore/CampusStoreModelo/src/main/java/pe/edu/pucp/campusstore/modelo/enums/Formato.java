package pe.edu.pucp.campusstore.modelo.enums;

public enum Formato {
    TAPA_BLANDA, TAPA_DURA, COLECCIONISTA
}
