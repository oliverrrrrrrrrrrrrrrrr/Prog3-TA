package pe.edu.pucp.campusstore.modelo.enums;

public enum TipoProducto {
    ARTICULO, LIBRO
}
