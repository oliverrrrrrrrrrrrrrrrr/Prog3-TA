package pe.edu.pucp.campusstore.dao;

import pe.edu.pucp.campusstore.modelo.Autor;



/**
 *
 * @author User
 */

public interface AutorDAO extends Persistible<Autor, Integer> {    
}
