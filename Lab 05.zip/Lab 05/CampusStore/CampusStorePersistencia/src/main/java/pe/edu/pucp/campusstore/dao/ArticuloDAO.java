
package pe.edu.pucp.campusstore.dao;
import java.sql.SQLException;
import java.util.List;
import pe.edu.pucp.campusstore.modelo.Articulo;
import pe.edu.pucp.campusstore.modelo.TipoArticulo;
/**
 *
 * @author AXEL
 */
public interface ArticuloDAO extends Persistible<Articulo, Integer> {
    
}
