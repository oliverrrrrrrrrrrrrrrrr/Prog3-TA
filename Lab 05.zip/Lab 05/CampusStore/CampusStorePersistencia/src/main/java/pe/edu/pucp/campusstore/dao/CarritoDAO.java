
package pe.edu.pucp.campusstore.dao;

import pe.edu.pucp.campusstore.modelo.Carrito;

/**
 *
 * @author User
 */
public interface CarritoDAO extends Persistible<Carrito, Integer> {    
}
