package pe.edu.pucp.campusstore.dao.temporal;

import pe.edu.pucp.campusstore.dao.Persistible;
import pe.edu.pucp.campusstore.modelo.Libro;


public interface LibroDAO extends Persistible<Libro, Integer> {
    
}
