package pe.edu.pucp.campusstore.db.utils;

public enum TipoDB {
    MySQL, 
    MSSQL
}
