package pe.edu.pucp.campusstore.modelo;

public enum Genero {
    MASCULINO, 
    FEMENINO
}
