package pe.edu.pucp.campusstore.modelo;

public enum TipoArticulo{
    LAPICERO, MOCHILA
    
}
