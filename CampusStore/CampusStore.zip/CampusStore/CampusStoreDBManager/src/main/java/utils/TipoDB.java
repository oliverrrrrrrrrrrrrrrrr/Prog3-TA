package utils;

public enum TipoDB {
    MySQL, 
    MSSQL
}