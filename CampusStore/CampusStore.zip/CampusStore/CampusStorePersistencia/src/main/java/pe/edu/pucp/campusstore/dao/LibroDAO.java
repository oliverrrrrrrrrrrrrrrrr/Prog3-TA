package pe.edu.pucp.campusstore.dao;

import pe.edu.pucp.campusstore.interfaces.dao.Persistible;
import pe.edu.pucp.campusstore.modelo.Libro;


public interface LibroDAO extends Persistible<Libro, Integer> {
    
}
