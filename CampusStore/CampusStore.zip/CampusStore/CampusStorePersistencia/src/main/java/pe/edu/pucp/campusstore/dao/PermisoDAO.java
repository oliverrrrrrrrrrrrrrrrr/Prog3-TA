package pe.edu.pucp.campusstore.dao;

import pe.edu.pucp.campusstore.interfaces.dao.Persistible;
import pe.edu.pucp.campusstore.modelo.Permiso;

public interface PermisoDAO extends Persistible<Permiso, Integer> {
    
}
