package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.OrdenCompra;

public interface OrdenCompraBO extends Gestionable<OrdenCompra>{
    
}
