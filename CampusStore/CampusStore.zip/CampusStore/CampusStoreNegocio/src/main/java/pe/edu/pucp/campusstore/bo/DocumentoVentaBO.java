package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.DocumentoVenta;

public interface DocumentoVentaBO extends Gestionable<DocumentoVenta>{
    
}
