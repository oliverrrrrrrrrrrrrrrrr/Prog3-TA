package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Empleado;

public interface EmpleadoBO extends Gestionable<Empleado>{
    
}
