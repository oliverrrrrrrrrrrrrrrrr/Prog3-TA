package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Articulo;

public interface ArticuloBO extends Gestionable<Articulo>{
    
}
