package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Libro;

public interface LibroBO extends Gestionable<Libro>{
    
}
