package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Autor;

public interface AutorBO extends Gestionable<Autor>{
    
}
