package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Reseña;

public interface ReseñaBO extends GestionableModelo<Reseña>{
    
}
