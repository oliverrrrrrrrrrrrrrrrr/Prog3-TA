package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Editorial;

public interface EditorialBO extends Gestionable<Editorial>{
    
}
