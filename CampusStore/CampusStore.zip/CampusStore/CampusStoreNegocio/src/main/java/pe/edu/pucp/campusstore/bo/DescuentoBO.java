package pe.edu.pucp.campusstore.bo;

import pe.edu.pucp.campusstore.modelo.Descuento;

public interface DescuentoBO extends GestionableModelo<Descuento>{
    
}
