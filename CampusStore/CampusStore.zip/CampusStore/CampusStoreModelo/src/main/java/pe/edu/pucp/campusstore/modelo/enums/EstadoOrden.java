package pe.edu.pucp.campusstore.modelo.enums;

public enum EstadoOrden {
    //POR_CANCELAR, CANCELADO, RECOGIDO, ANULADO
    NO_PAGADO, PAGADO, ENTREGADO
}
