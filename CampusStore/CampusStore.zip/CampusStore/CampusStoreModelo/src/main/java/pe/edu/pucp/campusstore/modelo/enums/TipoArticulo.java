package pe.edu.pucp.campusstore.modelo.enums;

public enum TipoArticulo{
    LAPICERO, CUADERNO, PELUCHE, TOMATODO
}
